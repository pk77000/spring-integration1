package com.capg.hsbc.com.capg.hsbc.springIng;

public class MyHelloService implements HelloService {

	public void sayHello(String name) {
		// TODO Auto-generated method stub
			System.out.println("Hello "+name);
		
	}

	public void test(String val) {
		// TODO Auto-generated method stub
		System.out.println("test"+val);
	}

}
