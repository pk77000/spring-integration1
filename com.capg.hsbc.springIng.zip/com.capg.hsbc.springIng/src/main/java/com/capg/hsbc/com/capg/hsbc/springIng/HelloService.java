package com.capg.hsbc.com.capg.hsbc.springIng;

public interface HelloService {
	void sayHello(String name);
	void test(String val);
}
