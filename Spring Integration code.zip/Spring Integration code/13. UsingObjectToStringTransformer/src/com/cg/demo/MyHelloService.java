package com.cg.demo;

public class MyHelloService implements HelloService {

	@Override
	public String sayHello(String name) {
		// TODO Auto-generated method stub
		System.out.println("In service activator");
		System.out.println("File received :: "+name);
		return "Hello "+name;
	}
}
