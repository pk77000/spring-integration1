package com.cg.demo;



public class MyHelloService {


	public String sayHello(String name) {
		// TODO Auto-generated method stub

		return "Hello "+name;
	}
}
