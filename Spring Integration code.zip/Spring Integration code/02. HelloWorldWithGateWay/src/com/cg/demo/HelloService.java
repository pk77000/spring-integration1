package com.cg.demo;


public interface HelloService {
	String sayHello(String name);
}
