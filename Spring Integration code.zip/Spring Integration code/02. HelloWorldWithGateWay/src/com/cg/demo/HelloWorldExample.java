package com.cg.demo;


import org.springframework.context.support.GenericXmlApplicationContext;


public class HelloWorldExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.load("context.xml");
		ctx.refresh();
		
		HelloService helloService = ctx.getBean("helloGateway",HelloService.class);
		
			System.out.println(helloService.sayHello("world"));
			
		
		System.out.println("The End");
	}

}
