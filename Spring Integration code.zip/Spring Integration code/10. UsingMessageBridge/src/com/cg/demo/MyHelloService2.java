package com.cg.demo;

import org.springframework.integration.Message;

public class MyHelloService2 implements HelloService {

	@Override
	public String sayHello(Message<?> name) {
		// TODO Auto-generated method stub
		System.out.println("In service 2 "+name.getPayload());
		

		return "Hello "+name;
	
		
	}

}
