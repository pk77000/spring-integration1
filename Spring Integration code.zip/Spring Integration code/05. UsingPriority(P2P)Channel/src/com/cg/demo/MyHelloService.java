package com.cg.demo;

import org.springframework.integration.Message;

public class MyHelloService implements HelloService {

	@Override
	public String sayHello(Message<?> name) {
		// TODO Auto-generated method stub
			System.out.println("In service 1 "+name.getPayload());
			
			try {
				Thread.sleep(20);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			return "Hello "+name;
	}
}
