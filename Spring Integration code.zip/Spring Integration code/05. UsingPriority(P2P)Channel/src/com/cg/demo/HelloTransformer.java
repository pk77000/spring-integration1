package com.cg.demo;

import org.springframework.integration.Message;
import org.springframework.integration.MessageHeaders;
import org.springframework.integration.support.MessageBuilder;

public class HelloTransformer {
	public Message<?> transform(Message<?> message){
		System.out.println("In transformer");
		if((""+message.getPayload()).contains(".JPG"))
		{
			//System.out.println("File :: "+message.getPayload());
			Message<?> newMessage = MessageBuilder.fromMessage(message).setHeader(MessageHeaders.PRIORITY, 10000).build();
			return newMessage;
		}
		else
		{
			//System.out.println("File :: "+message.getPayload());
			Message<?> newMessage = MessageBuilder.fromMessage(message).setHeader(MessageHeaders.PRIORITY, 1).build();
			return newMessage;
			
		}
//		return message;
	}
}
