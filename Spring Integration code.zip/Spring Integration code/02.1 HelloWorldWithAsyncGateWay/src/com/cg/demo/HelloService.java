package com.cg.demo;

import java.util.concurrent.Future;



public interface HelloService {
	Future<String> sayHello(String name);
}
