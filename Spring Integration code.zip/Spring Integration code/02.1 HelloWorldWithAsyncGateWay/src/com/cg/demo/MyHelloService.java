package com.cg.demo;



public class MyHelloService {


	public String sayHello(String name) {
		// TODO Auto-generated method stub

		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Hello "+name;
	}
}
