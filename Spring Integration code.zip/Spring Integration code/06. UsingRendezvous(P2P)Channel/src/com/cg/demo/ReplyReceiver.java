package com.cg.demo;

import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.MessageHeaders;

public class ReplyReceiver {
	public void receiveReply(Message<?> message){
		
		System.out.println("Message received by Service Activator");
		//MessageChannel replyChannel = (MessageChannel)message.getHeaders().get(MessageHeaders.REPLY_CHANNEL);
		//System.out.println("jjjj"+replyChannel);
		//replyChannel.send(message);
	
	}
}
