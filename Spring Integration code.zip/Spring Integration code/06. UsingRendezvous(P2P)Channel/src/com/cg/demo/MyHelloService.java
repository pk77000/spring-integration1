package com.cg.demo;

import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.MessageHeaders;

public class MyHelloService implements HelloService {

	@Override
	public void sayHello(Message<?> name) {
		// TODO Auto-generated method stub
			System.out.println("In service 1 ");
			MessageChannel replyChannel = (MessageChannel)name.getHeaders().get(MessageHeaders.REPLY_CHANNEL);

			replyChannel.send(name);
			System.out.println("Msg received");
	}
}
