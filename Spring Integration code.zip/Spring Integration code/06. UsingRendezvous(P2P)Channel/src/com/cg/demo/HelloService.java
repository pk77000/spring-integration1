package com.cg.demo;

import org.springframework.integration.Message;

public interface HelloService {
	void sayHello(Message<?> message);
}
