package com.cg.demo;

import org.springframework.integration.Message;
import org.springframework.integration.MessageHeaders;
import org.springframework.integration.support.MessageBuilder;


public class HelloTransformer {
	public Message<?> transform(Message<?> message){
		System.out.println("In transformer");
		message = MessageBuilder.withPayload(message).setHeader(MessageHeaders.REPLY_CHANNEL, "replyChannel").build();
		return message;
	}
}
