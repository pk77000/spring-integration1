package com.cg.demo;

import org.springframework.integration.Message;

public class MyHelloService3 implements HelloService {

	@Override
	public String sayHello(Message<?> message) {
		// TODO Auto-generated method stub
		return null;
	}

}
