package com.cg.demo;

import org.springframework.integration.Message;

public class MessageEnricher {
	public String enrichMessage(Message <?> message){
		
		return "aaa";
		
	}
}
