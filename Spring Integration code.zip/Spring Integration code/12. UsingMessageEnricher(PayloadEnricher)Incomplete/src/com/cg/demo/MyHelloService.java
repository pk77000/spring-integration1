package com.cg.demo;

import org.springframework.integration.Message;

public class MyHelloService implements HelloService {

	@Override
	public String sayHello(Message<?> name) {
		// TODO Auto-generated method stub
			System.out.println("File received :: "+name.getPayload());
			
			return "Hello "+name;
	}
}
