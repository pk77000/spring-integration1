

package com.cg.demo;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class CustomerConverter implements Converter<Map<String, String>, Customer> {
    @Override
    public Customer convert(Map<String, String> customerMap) {
    	System.out.println("Map :: "+customerMap);
        Customer customer = new Customer();

        customer.setFirstName(customerMap.get("firstName"));
        customer.setLastName(customerMap.get("lastName"));
        customer.setAddress(customerMap.get("address"));
        customer.setCity(customerMap.get("city"));
        customer.setState(customerMap.get("state"));
        customer.setZip(customerMap.get("zip"));
        return customer;
    }
}
