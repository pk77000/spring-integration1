package com.cg.demo;

import org.springframework.integration.Message;

public class HelloTransformer {
		public String Transform(Message<?> message){
			System.out.println("In transformer");
			return "Hello :: "+message;
			
		}
}
