package com.cg.demo;

public interface HelloService {
	Exhibit sayHello(String message);
}
