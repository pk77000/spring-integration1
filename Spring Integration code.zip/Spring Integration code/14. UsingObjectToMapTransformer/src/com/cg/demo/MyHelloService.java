package com.cg.demo;

public class MyHelloService implements HelloService {

	@Override
	public Exhibit sayHello(String name) {
		// TODO Auto-generated method stub
		System.out.println("In service activator");
		System.out.println("File received :: "+name);
		Exhibit e = new Exhibit();
		e.setFileName(name);
		return e;
	}
}
