package com.cg.demo;

public class Exhibit {
	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "Exhibit [fileName=" + fileName + "]";
	}
}
