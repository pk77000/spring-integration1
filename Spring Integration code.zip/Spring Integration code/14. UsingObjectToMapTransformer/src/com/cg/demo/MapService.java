package com.cg.demo;

import java.util.Map;

public class MapService {
	public void processMap(Map<String, String> map){
		System.out.println("Map :: "+ map);
	}
}
